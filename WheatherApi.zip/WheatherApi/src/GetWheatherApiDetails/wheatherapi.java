package GetWheatherApiDetails;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

@SuppressWarnings("serial")
@WebServlet("/wheatherapi")
public class wheatherapi extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NullPointerException {

		JSONObject resp = new JSONObject();
		try {

			if (request.getParameter("zipcode") != null && request.getParameter("zipcode") != "") {

				String zipCode = request.getParameter("zipcode");
				System.out.println("zipCode::" + zipCode);
				String nextDate = config.getNextDate();
				System.out.println("nextDate::" + nextDate);
				JSONObject getWheatherApi = config.getwheatherapi(zipCode, nextDate);
				System.out.println("Response from getWheatherApi::" + getWheatherApi);
				response.setContentType("application/json");
				response.getWriter().println(getWheatherApi);

			} else {
				System.out.println("zipCode is Empty or Null");

				resp.put("message", "zipCode is Empty or Null");
				resp.put("status_code", "204");
				response.setStatus(HttpServletResponse.SC_OK);
				response.setContentType("application/json");
				response.getWriter().println(resp);
			}

		} catch (Exception e) {
			System.out.println("Exception: " + e.toString());
			e.printStackTrace(System.err);
			resp.put("message", "Internal server error");
			resp.put("status_code", "500");
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().println(resp);
		}

	}

}
