package GetWheatherApiDetails;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.json.JSONArray;
import org.json.JSONObject;

public class config {

	
	
	
	public static String APIKEY="14ae533050e543beaa384201210210";
	
	
	public static String getNextDate() throws ParseException {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd"); 		
		dateFormatter.setTimeZone(TimeZone.getTimeZone("IST"));
	 	String curDate=dateFormatter.format(new Date());
		  final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		  final Date date = format.parse(curDate);
		  final Calendar calendar = Calendar.getInstance();
		  calendar.setTime(date);
		  calendar.add(Calendar.DAY_OF_YEAR, 1);
		  return format.format(calendar.getTime()); 
		}
	
	
	public static JSONObject getwheatherapi(String zipCode,String date) {
		
		JSONObject apiResponse = null;
		try 
		{

			URL url = new URL("https://api.weatherapi.com/v1/forecast.json?key=" + config.APIKEY + "&q=" + zipCode
					+ "&date=" + date);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);

			StringBuilder result = new StringBuilder();
			System.out.println("Response Code : " + connection.getResponseCode());
			if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {

				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String decodedString;
				while ((decodedString = in.readLine()) != null) {
					result.append(decodedString);
					result.append(System.getProperty("line.separator"));
				}
				System.out.println("Success Response :" + result);
				JSONObject data = new JSONObject(result.toString());

				String forecast = data.get("forecast").toString().trim();
				System.out.println("forecast" + forecast);
				JSONObject foreCastJsonObj = new JSONObject(forecast.toString());
				String forecastday = foreCastJsonObj.get("forecastday").toString().trim();
				System.out.println("forecastday" + forecastday);
				JSONArray forecastdayJson = foreCastJsonObj.getJSONArray("forecastday");
				System.out.println("forecastdayJson::" + forecastdayJson);
				String forecastdate = forecastdayJson.getJSONObject(0).get("date").toString();
				JSONObject forecastdayJsonObj = (JSONObject) forecastdayJson.getJSONObject(0).get("day");
				forecastdayJsonObj.put("date", forecastdate);
				System.out.println("foreCast Day JsonObj:: " + forecastdayJsonObj);
				apiResponse =  forecastdayJsonObj;

			} 
			else 
			{
				System.out.println("Fail");
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String decodedString;
				while ((decodedString = in.readLine()) != null) {
					result.append(decodedString);
					result.append(System.getProperty("line.separator"));
				}
				System.out.println("Fail Response :" + decodedString);
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e.toString());
			e.printStackTrace(System.err);
		}
		return apiResponse;
	}
	
}
